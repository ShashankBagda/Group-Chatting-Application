// To convert UI file to PY file
python -m PyQt5.uic.pyuic -x main.ui -o main.py

// First make a [free PubNub account]
//(https://dashboard.pubnub.com/signup?devrel_gh=python-desktop-chat-application) to instantly get API keys.


// Command to Run


pip3 install -r requirements.txt
python3 chatapp.py